<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProgsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('progs', function (Blueprint $table) {
             $table->bigIncrements('id');
            $table->string("progCode")->unique();
            $table->string("progName");
            $table->string("progDesc");
            $table->integer("durationOfYear");
            $table->string("mer");
            $table->string("professional");
            $table->string("campuses");
            $table->integer("yearAdd");
            $table->unsignedBigInteger('facId')->nullable();
            $table->foreign('facId')->references('id')->on('faculties');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('progs');
    }
}
