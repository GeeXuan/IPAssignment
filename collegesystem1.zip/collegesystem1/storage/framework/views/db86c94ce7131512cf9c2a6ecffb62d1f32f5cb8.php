<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <h3>List Programme</h3>
      </div>
      <div class="col-sm-2">
        <a class="btn btn-sm btn btn-dark"  href="<?php echo e(route('prog.create')); ?>">Create New Programme</a>
      </div>
        
    </div>

    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
      </div>
    <?php endif; ?>

    <br/>
    
    <table class="table">
        <thead class="black white-text" style='background-color: black; color:white'>
      <tr>
        <th width = "50px"><b>No.</b></th>
        <th width = "300px">Programme Code</th>
        <th width = "300px">Programme Name</th>
       
        <th width = "180px">Action</th>
      </tr>
        </thead>
      <?php $__currentLoopData = $progs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><b><?php echo e(++$i); ?>.</b></td>
          <td><?php echo e($prog->progCode); ?></td>
          <td><?php echo e($prog->progName); ?></td>
          
          <td>
            <form action="<?php echo e(route('prog.destroy', $prog->id)); ?>" method="post">
              
              <a class="btn btn-sm btn btn-dark" style='padding:10px;' href="<?php echo e(route('prog.show',$prog->id)); ?>">Show</a>
              <a class="btn btn-sm btn btn-dark" style='padding:10px;' href="<?php echo e(route('prog.edit',$prog->id)); ?>">Edit</a>
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-outline-danger waves-effect">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
     
<?php echo $progs->links(); ?>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/prog/index.blade.php ENDPATH**/ ?>