<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>New Programme</h3>
      </div>
    </div>

    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <strong>Whoops! </strong> there where some problems with your input.<br>
        <ul>
          <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('prog.store')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-md-12">
          <strong>Programme Code:</strong>
          <input type="text" name="progCode" class="form-control" placeholder="Programme Code" pattern="(?=.*[A-Z]).{3,}">
        </div>
          <div class="col-md-12">
          <strong>Programme Name:</strong>
          <input type="text" name="progName" class="form-control" placeholder="Programme Name">
        </div>
          <div class="col-md-12">
          <strong>Programme Description:</strong>
          <input type="text" name="progDesc" class="form-control" placeholder="Programme Description">
        </div>
          <div class="col-md-12">
          <strong>Duration Of Year:</strong>
<!--          <input type="text" name="durationOfYear" class="form-control" placeholder="Duration Of Year">-->
           
           <select name="durationOfYear" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
        
        </div>
        <div class="col-md-12">
          <strong>Minimum Entry Requirement :</strong>
          <input type="text" name="mer" class="form-control" placeholder="Minimum Entry Requirement">
        </div>
          <div class="col-md-12">
          <strong>Professional:</strong>
          <input type="text" name="professional" class="form-control" placeholder="Professional">
        </div>
        <div class="col-md-12">
          <strong>Campuses Offered :</strong>
           <select name="campuses" class="form-control">
            <option value="All" >All</option>
            <option value="KL Campus">KL Campus</option>
            <option value="Johor Campus" >Johor Campus</option>
            <option value="Penang Campus">Penang Campus</option>
          </select>
        </div>
         <div class="col-md-12">
          <strong>Year Created:</strong>
          <input type="text" name="yearAdd" class="form-control" placeholder="Year Created this programme" pattern="\d*">
        </div>
        <div class="col-md-12">
          <strong>Faculty Code:</strong>
          <select name="facId" class="form-control">
              <?php $__currentLoopData = $facs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($fac->id); ?>"><?php echo e($fac->facultyCode); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </select>
          
          </div>
     
        
        </div>
        <div class="col-md-12">
            <br/>
          <a href="<?php echo e(route('prog.index')); ?>" class="btn btn-sm btn btn-dark">Back</a>
          <button type="submit" class="btn btn-indigo">Submit</button>
        </div>
      </div>
    </form>

  </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/prog/create.blade.php ENDPATH**/ ?>