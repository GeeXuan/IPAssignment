<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3>Programme Details</h3>
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Code : </strong> <?php echo e($prog->progCode); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Name : </strong> <?php echo e($prog->progName); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Description : </strong> <?php echo e($prog->progDesc); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Duration Of Year : </strong> <?php echo e($prog->durationOfYear); ?>

        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <strong>Minimum Entry Requirements : </strong> <?php echo e($prog->mer); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Incorpartion Of Professional Curriculum : </strong> <?php echo e($prog->professional); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Campuses Offered : </strong> <?php echo e($prog->campuses); ?>

        </div>
      </div>
        <div class="col-md-12">
        <div class="form-group">
          <strong>Year Created : </strong> <?php echo e($prog->yearAdd); ?>

        </div>
      </div>
        <div class="col-md-12">
        <div class="form-group">
          <strong>Faculty Id : </strong> <?php echo e($prog->facId); ?>

        </div>
      </div>
      <div class="col-md-12">
        <a href="<?php echo e(route('prog.index')); ?>" class="btn btn-sm btn btn-dark">Back</a>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/prog/detail.blade.php ENDPATH**/ ?>