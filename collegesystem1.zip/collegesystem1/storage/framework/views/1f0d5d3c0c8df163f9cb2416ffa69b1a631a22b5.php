<?php
require_once 'C:\xampp\htdocs\collegesystem1\app\ProgFacade.php';
$facade = new \App\ProgFacade();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
  </head>
  <body>
    <h1>Programme and Course By Year</h1>
    <form method="post">
      Enter the year
      <p>Year:<input type="text" name="years" value="" size="20" /></p>
      
      <p><input type="submit" value="Submit" name="submit"/></p>
    </form >
    <?php
    if (isset($_POST["submit"])) {
      $year = trim($_POST["years"]);
      $facade->getProgCourseDetails($year);
    }
    ?>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/prog/prog.blade.php ENDPATH**/ ?>