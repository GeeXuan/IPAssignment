<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>New Course</h3>
      </div>
    </div>

    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <strong>Whoops! </strong> there where some problems with your input.<br>
        <ul>
          <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('course.store')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-md-12">
          <strong>Course Code:</strong>
          <input type="text" name="courseCode" class="form-control" placeholder="Course Code" pattern="(?=.*\d)(?=.*[A-Z]).{8}">
        </div>
          <div class="col-md-12">
          <strong>Course Name:</strong>
          <input type="text" name="courseName" class="form-control" placeholder="Course Name">
        </div>
          <div class="col-md-12">
          <strong>Course Description:</strong>
          <input type="text" name="courseDesc" class="form-control" placeholder="Course Description">
        </div>
          <div class="col-md-12">
          <strong>Credit Hour:</strong>
<!--          <input type="text" name="durationOfYear" class="form-control" placeholder="Duration Of Year">-->
           
           <select name="creditHour" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
        
        </div>
          <div class="col-md-12">
          <strong>Year Created:</strong>
          <input type="text" name="yearAdd" class="form-control" placeholder="Year Created" pattern="\d*">
         </div>
          <div class="col-md-12">
          <strong>Programme Name:</strong>
          <select name="progId" class="form-control">
              <?php $__currentLoopData = $progs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($prog->id); ?>" ><?php echo e($prog->progCode); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </select>
          
          </div>
        
        <div class="col-md-12">
            <br/>
          <a href="<?php echo e(route('course.index')); ?>" class="btn btn-sm btn btn-dark">Back</a>
          <button type="submit" class="btn btn-indigo">Submit</button>
        </div>
      </div>
    </form>
    <p>&nbsp;</p>
      <h3>
        <?php
        if (isset($_POST['submit'])) {
          $courseCode = $_POST['courseCode'];
          $courseName = $_POST['courseName'];
          $courseDesc = $_POST['courseDesc'];
          $creditHour = $_POST['creditHour'];
          $yearAdd = $_POST['yearAdd'];
          $progId = $_POST['progId'];
          
          $url = "http://localhost:8000/../resources/views/CourseApi.php?courseCode=" . $courseCode."&couseName=".$courseName."&courseDesc=".$courseDesc."&creditHour=".$creditHour."&yearAdd=".$yearAdd."&progId=".progId;

          $client = curl_init($url);
          curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
          $response = curl_exec($client);

          $result = json_decode($response);
          
          $msg = "The url is".url;
          return redirect()->back() ->with('alert', $msg);
        }
        ?>
          
      </h3>
  </div>
<script>
    var msg = '<?php echo e(Session::get('alert')); ?>';
    var exist = '<?php echo e(Session::has('alert')); ?>';
    if(exist){
      alert(msg);
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/course/create.blade.php ENDPATH**/ ?>