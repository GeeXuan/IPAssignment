<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3>Detail Course</h3>
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <strong>Course Code : </strong> <?php echo e($course->courseCode); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Course Name : </strong> <?php echo e($course->courseName); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Course Description : </strong> <?php echo e($course->courseDesc); ?>

        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Credit Hour: </strong> <?php echo e($course->creditHour); ?>

        </div>
      </div>
        <div class="col-md-12">
        <div class="form-group">
          <strong>Year Created: </strong> <?php echo e($course->yearAdd); ?>

        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Name: </strong> 
          <?php $__currentLoopData = $progs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($course->progId == $prog->id): ?>
            <?php echo e($prog->progCode); ?>

            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
      </div>
      <div class="col-md-12">
        <a href="<?php echo e(route('course.index')); ?>" class="btn btn-sm btn btn-dark">Back</a>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/course/detail.blade.php ENDPATH**/ ?>