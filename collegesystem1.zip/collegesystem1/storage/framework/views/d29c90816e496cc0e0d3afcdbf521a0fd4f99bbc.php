<?php $__env->startSection('content'); ?>
 <?php
require_once 'C:\xampp\htdocs\collegesystem1\app\ProgFacade.php';
$facade = new ProgFacade();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
  </head>
  <body>
    <h1>Risky Travel Agent</h1>
  <form action="" method="post">
       <?php echo method_field('PUT'); ?> 
      Enter the start date and end date for your trip.
      <p>Start Date:<input type="text" name="years" value="" size="20" /></p>

      <p><input type="submit" value="Submit" name="submit"/></p>
    </form >
    <?php
    if (isset($_POST["submit"])) {
      $from = trim($_POST["years"]);
     
      route($facade->getFlightsAndHotels($from));
    }
    ?>
  </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\collegesystem1\resources\views/prog/FaceApp.blade.php ENDPATH**/ ?>