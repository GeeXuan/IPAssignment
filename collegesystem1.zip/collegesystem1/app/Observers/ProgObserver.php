<?php

namespace App\Observers;
use App\Prog;
use App\Http\Controllers\ProgController;

class ProgObserver {
    
    public function created(Prog $prog){
        //dd("new programme is created");
       return redirect()->back() ->with('alert', 'Created!');
    }
    public function updated(Prog $prog){
        //dd("new programme is created");
       return redirect()->back() ->with('alert', 'Updated!');
    } 
}
