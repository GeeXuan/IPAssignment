<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Prog;
use App\ProgProxy;
use App\Course;
use DOMDocument;
class ProgController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        
        $progs = Prog::latest()->paginate(5);
        $courses = Course::latest();
      
        
        $xmlProg = new DOMDocument("1.0","UTF-8");
        $xmlProg->formatOutput=true;
        $xslt=$xmlProg->createProcessingInstruction('xml-stylesheet', 'type="text/xsl" href="progsDetails.xsl"');

        $xmlProg->appendChild($xslt);
        $progsTag = $xmlProg->createElement("progs");
        foreach ($progs as $prog){
            $progTag = $xmlProg->createElement("prog");
            $ProgCode = $xmlProg->createElement("progCode",$prog->progCode);
            $ProgName = $xmlProg->createElement("progName",$prog->progName);
            $ProgDesc = $xmlProg->createElement("progDesc",$prog->progDesc);
            $DurationOfYear = $xmlProg->createElement("durationOfYear",$prog->durationOfYear);
            $MER = $xmlProg->createElement("mer",$prog->mer);
            $Professional = $xmlProg->createElement("professional",$prog->professional);
            $Campuses = $xmlProg->createElement("campuses",$prog->campuses);
            $YearAdd = $xmlProg->createElement("yearAdd",$prog->yearAdd);
            $FacId = $xmlProg->createElement("facId",$prog->facId);
            $progTag->appendChild($ProgCode);
            $progTag->appendChild($ProgName);
            $progTag->appendChild($ProgDesc);
            $progTag->appendChild($DurationOfYear);
            $progTag->appendChild($MER);
            $progTag->appendChild($Professional);
            $progTag->appendChild($Campuses);
            $progTag->appendChild($YearAdd);
            $progTag->appendChild($FacId);
            $progsTag->appendChild($progTag);
             
        }
        
        $xmlProg->appendChild($progsTag);
        $xmlProg->save('../resources/views/xml/progsDetails.xml');
        return view('prog.index',compact('progs','courses'))
                ->with('i',(request()->input('page',1)-1)*5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $facs = \App\Faculty::all();
        return view('prog.create',compact('facs'));
      
    }
    
    
   
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $request->validate([
          'progCode' => 'required',
          'progName' => 'required',
          'progDesc' => 'required',
          'durationOfYear' => 'required',
          'mer' => 'required',
          'professional' => 'required',
          'campuses' => 'required',
          'yearAdd' => 'required',
           'facId' => 'required'
        ]);
        
        Prog::create($request->all());
        
        return redirect()->route('prog.index')
                        ->with('success', 'New Programme Created Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
          $prog = Prog::find($id);
        return view('prog.detail', compact('prog'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $prog = Prog::find($id);
        return view('prog.edit', compact('prog'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $request->validate([
          'progCode' => 'required',
          'progName' => 'required',
          'progDesc' => 'required',
          'durationOfYear' => 'required',
          'mer' => 'required',
          'professional' => 'required',
          'campuses' => 'required',
             'yearAdd' => 'required',
             'facId' => 'required'
        ]);
        $prog = Prog::find($id);
        $prog->progCode = $request->get('progCode');
        $prog->progName = $request->get('progName');
        $prog->progDesc = $request->get('progDesc');
        $prog->durationOfYear = $request->get('durationOfYear');
        $prog->mer = $request->get('mer');
        $prog->professional = $request->get('professional');
        $prog->campuses = $request->get('campuses');
        $prog->yearAdd = $request->get('yearAdd');
        $prog->facId = $request->get('facId');
        $prog->save();
        return redirect()->route('prog.index')
                         ->with('success',"Programme updated successfully");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
         $prog = Prog::find($id);
        $prog->delete();
        return redirect()->route('prog.index')
                         ->with('success',"Programme deleted successfully");
    }
    
   
}
