<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Course;
use DOMDocument;
class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $courses = Course::latest()->paginate(5);
         
         
        $xmlCourse = new DOMDocument("1.0","UTF-8");
        $xmlCourse->formatOutput=true;
        $xslt=$xmlCourse->createProcessingInstruction('xml-stylesheet', 'type="text/xsl" href="coursesDetails.xsl"');

        $xmlCourse->appendChild($xslt);
        $coursesTag = $xmlCourse->createElement("courses");
        foreach ($courses as $course){
            $courseTag = $xmlCourse->createElement("course");
            $CourseCode = $xmlCourse->createElement("courseCode",$course->courseCode);
            $CourseName = $xmlCourse->createElement("courseName",$course->courseName);
            $CourseDesc = $xmlCourse->createElement("courseDesc",$course->courseDesc);
            $CreditHour = $xmlCourse->createElement("creditHour",$course->creditHour);
            $YearAdd = $xmlCourse->createElement("yearAdd",$course->yearAdd);
            $ProgId = $xmlCourse->createElement("progId",$course->progId);
            $courseTag->appendChild($CourseCode);
            $courseTag->appendChild($CourseName);
            $courseTag->appendChild($CourseDesc);
            $courseTag->appendChild($CreditHour);
            $courseTag->appendChild($YearAdd);
            $courseTag->appendChild($ProgId);
            $coursesTag->appendChild($courseTag);
             
        }
        
        $xmlCourse->appendChild($coursesTag);
        $xmlCourse->save('../resources/views/xml/coursesDetails.xml');
         return view('course.index',compact('courses'))
                ->with('i',(request()->input('page',1)-1)*5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $progs = \App\Prog::all();
        return view('course.create',compact('progs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   
    public function store(Request $request)
    {
         $request->validate([
          'courseCode' => 'required',
          'courseName' => 'required',
          'courseDesc' => 'required',
          'creditHour' => 'required',
             'yearAdd' => 'required',
             'progId' => 'required'
          
        ]);
        
        Course::create($request->all());
        return redirect()->route('course.index')
                        ->with('success', 'New Course Created Successfully');
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $course = Course::find($id);
         $progs = \App\Prog::all();
        return view('course.detail', compact('course','progs'));
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $course = Course::find($id);
        return view('course.edit', compact('course'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $request->validate([
          'courseCode' => 'required',
          'courseName' => 'required',
          'courseDesc' => 'required',
          'creditHour' => 'required',
             'yearAdd' => 'required',
             'progId' => 'required'
          
        ]);
        $course = Course::find($id);
        $course->courseCode = $request->get('courseCode');
        $course->courseName = $request->get('courseName');
        $course->courseDesc = $request->get('courseDesc');
        $course->creditHour = $request->get('creditHour');
        $course->yearAdd = $request->get('yearAdd');
        $course->progId = $request->get('progId');
        $course->save();
        return redirect()->route('course.index')
                         ->with('success',"Course updated successfully");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $course = Course::find($id);
        $course->delete();
        return redirect()->route('course.index')
                         ->with('success',"Course deleted successfully");
    }
     
}
