<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Events\ProgCreated;

class Prog extends Model
{
     protected $fillable = ['progCode','progName','progDesc','durationOfYear','mer','professional','campuses','yearAdd','facId'];
     

}
