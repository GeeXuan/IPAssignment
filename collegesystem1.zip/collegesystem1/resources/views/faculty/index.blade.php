@extends('layouts.app')
@section('content')

  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <h3>List Course</h3>
      </div>
      <div class="col-sm-2">
        <a class="btn btn-sm btn btn-dark" href="{{ route('course.create') }}">Create New Faculty</a>
      </div>
    </div>

    @if ($message = Session::get('success'))
      <div class="alert alert-success">
        <p>{{$message}}</p>
      </div>
    @endif

    <table class="table">
         <thead class="black white-text" style='background-color: black; color:white'>
      
      <tr>
        <th width = "50px"><b>No.</b></th>
        <th width = "300px">Faculty Code</th>
        <th width = "300px">Faculty Name</th>
       
        <th width = "180px">Action</th>
      </tr>
    </thead>
      @foreach ($facs as $fac)
        <tr>
          <td><b>{{++$i}}.</b></td>
          <td>{{$fac->facultyCode}}</td>
          <td>{{$fac->facultyName}}</td>
          
          <td>
            <form action="{{ route('faculty.destroy', $fac->id) }}" method="post">
              <a class="btn btn-sm btn btn-dark" style='padding:10px;' href="{{route('faculty.show',$fac->id)}}">Show</a>
              <a class="btn btn-sm btn btn-dark" style='padding:10px;' href="{{route('faculty.edit',$fac->id)}}">Edit</a>
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-outline-danger waves-effect">Delete</button>
            </form>
          </td>
        </tr>
      @endforeach
    </table>
    
    <br/><br/>
     
{!! $facs->links() !!}
  </div>
@endsection