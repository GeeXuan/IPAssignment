@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>Edit Programme Details</h3>
      </div>
    </div>

    @if ($errors->any())
      <div class="alert alert-danger">
        <strong>Whoops! </strong> there where some problems with your input.<br>
        <ul>
          @foreach ($errors as $error)
            <li>{{$error}}</li>
          @endforeach
        </ul>
      </div>
    @endif

    <form action="{{route('prog.update',$prog->id)}}" method="post">
      @csrf
      @method('PUT')
      <div class="row">
        <div class="col-md-12">
          <strong>Programme Code:</strong>
          <input type="text" name="progCode" class="form-control" value="{{$prog->progCode}}" pattern="(?=.*[A-Z]).{3,}">
        </div>
          <div class="col-md-12">
          <strong>Programme Name:</strong>
          <input type="text" name="progName" class="form-control" value="{{$prog->progName}}">
        </div>
          <div class="col-md-12">
          <strong>Programme Description:</strong>
          <input type="text" name="progDesc" class="form-control" value="{{$prog->progDesc}}">
        </div>
          <div class="col-md-12">
          <strong>Duration Of Year:</strong>
<!--          <input type="text" name="durationOfYear" class="form-control" value="{{$prog->durationOfYear}}">-->
          @if ($prog->durationOfYear == "1")
           <select name="durationOfYear" class="form-control">
            <option value="1" selected="selected">1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
          @endif
          @if ($prog->durationOfYear == "2")
           <select name="durationOfYear" class="form-control">
            <option value="1" >1</option>
            <option value="2" selected="selected">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
          @endif
          @if ($prog->durationOfYear == "3")
           <select name="durationOfYear" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" selected="selected" >3</option>
            <option value="4">4</option>
          </select>
          @endif
          @if ($prog->durationOfYear == "4")
           <select name="durationOfYear" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4" selected="selected">4</option>
          </select>
          @endif
        </div>
        
        <div class="col-md-12">
          <strong>Minimum Entry Requirements: </strong>
          <input type="text" name="mer" class="form-control" value="{{$prog->mer}}">
        </div>
        <div class="col-md-12">
          <strong>Incorporation Of Professional Curriculum:</strong>
          <input type="text" name="professional" class="form-control" value="{{$prog->professional}}">
        </div>
          <div class="col-md-12">
          <strong>Campuses Offered: </strong>
           @if ($prog->campuses == "All")
           <select name="campuses" class="form-control">
               <option value="All" selected="selected">All</option>
            <option value="KL Campus">KL Campus</option>
            <option value="Johor Campus" >Johor Campus</option>
            <option value="Penang Campus">Penang Campus</option>
          </select>
          @endif
          @if ($prog->campuses == "KL Campus")
           <select name="campuses" class="form-control">
            <option value="All" >All</option>
            <option value="KL Campus" selected="selected">KL Campus</option>
            <option value="Johor Campus" >Johor Campus</option>
            <option value="Penang Campus">Penang Campus</option>
          </select>
          @endif
          @if ($prog->campuses == "Johor Campus")
           <select name="campuses" class="form-control">
            <option value="All" >All</option>
            <option value="KL Campus">KL Campus</option>
            <option value="Johor Campus" selected="selected">Johor Campus</option>
            <option value="Penang Campus">Penang Campus</option>
          </select>
          @endif
          @if ($prog->campuses == "Penang Campus")
           <select name="campuses" class="form-control">
           <option value="All" >All</option>
            <option value="KL Campus">KL Campus</option>
            <option value="Johor Campus" >Johor Campus</option>
            <option value="Penang Campus" selected="selected">Penang Campus</option>
          </select>
          @endif
        </div>
          <div class="col-md-12">
          <strong>Year Created: </strong>
          <input type="text" name="yearAdd" class="form-control" value="{{$prog->yearAdd}}" pattern="\d*">
        </div>
          <div class="col-md-12">
          <strong>Faculty Id: </strong>
           <input type="text" name="facId" class="form-control" value="{{$prog->facId}}" pattern="\d*">
          </select>
         
          </div>
          <br/>
        <div class="col-md-12">
            <br/>
          <a href="{{route('prog.index')}}" class="btn btn-sm btn btn-dark">Back</a>
          <button type="submit" class="btn btn-indigo">Submit</button>
        </div>
      </div>
    </form>
  </div>
@endsection