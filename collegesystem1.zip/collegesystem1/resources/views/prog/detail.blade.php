@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3>Programme Details</h3>
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Code : </strong> {{$prog->progCode}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Name : </strong> {{$prog->progName}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Description : </strong> {{$prog->progDesc}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Duration Of Year : </strong> {{$prog->durationOfYear}}
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <strong>Minimum Entry Requirements : </strong> {{$prog->mer}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Incorpartion Of Professional Curriculum : </strong> {{$prog->professional}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Campuses Offered : </strong> {{$prog->campuses}}
        </div>
      </div>
        <div class="col-md-12">
        <div class="form-group">
          <strong>Year Created : </strong> {{$prog->yearAdd}}
        </div>
      </div>
        <div class="col-md-12">
        <div class="form-group">
          <strong>Faculty Id : </strong> {{$prog->facId}}
        </div>
      </div>
      <div class="col-md-12">
        <a href="{{route('prog.index')}}" class="btn btn-sm btn btn-dark">Back</a>
      </div>
    </div>
  </div>
@endsection