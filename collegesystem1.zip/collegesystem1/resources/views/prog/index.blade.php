@extends('layouts.app')
@section('content')

  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <h3>List Programme</h3>
      </div>
      <div class="col-sm-2">
        <a class="btn btn-sm btn btn-dark"  href="{{ route('prog.create') }}">Create New Programme</a>
      </div>
        
    </div>

    @if ($message = Session::get('success'))
      <div class="alert alert-success">
        <p>{{$message}}</p>
      </div>
    @endif

    <br/>
    
    <table class="table">
        <thead class="black white-text" style='background-color: black; color:white'>
      <tr>
        <th width = "50px"><b>No.</b></th>
        <th width = "300px">Programme Code</th>
        <th width = "300px">Programme Name</th>
       
        <th width = "180px">Action</th>
      </tr>
        </thead>
      @foreach ($progs as $prog)
        <tr>
          <td><b>{{++$i}}.</b></td>
          <td>{{$prog->progCode}}</td>
          <td>{{$prog->progName}}</td>
          
          <td>
            <form action="{{ route('prog.destroy', $prog->id) }}" method="post">
              
              <a class="btn btn-sm btn btn-dark" style='padding:10px;' href="{{route('prog.show',$prog->id)}}">Show</a>
              <a class="btn btn-sm btn btn-dark" style='padding:10px;' href="{{route('prog.edit',$prog->id)}}">Edit</a>
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-outline-danger waves-effect">Delete</button>
            </form>
          </td>
        </tr>
      @endforeach
    </table>
    <script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
     
{!! $progs->links() !!}
  </div>
@endsection