@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>Edit Course Details</h3>
      </div>
    </div>

    @if ($errors->any())
      <div class="alert alert-danger">
        <strong>Whoops! </strong> there where some problems with your input.<br>
        <ul>
          @foreach ($errors as $error)
            <li>{{$error}}</li>
          @endforeach
        </ul>
      </div>
    @endif

    <form action="{{route('course.update',$course->id)}}" method="post">
      @csrf
      @method('PUT')
      <div class="row">
        <div class="col-md-12">
          <strong>Course Code:</strong>
          <input type="text" name="courseCode" class="form-control" value="{{$course->courseCode}}" pattern="(?=.*\d)(?=.*[A-Z]).{8}">
        </div>
          <div class="col-md-12">
          <strong>Course Name:</strong>
          <input type="text" name="courseName" class="form-control" value="{{$course->courseName}}">
        </div>
          <div class="col-md-12">
          <strong>Course Description:</strong>
          <input type="text" name="courseDesc" class="form-control" value="{{$course->courseDesc}}">
        </div>
          <div class="col-md-12">
          <strong>Credit Hour:</strong>

          @if ($course->creditHour == "1")
           <select name="creditHour" class="form-control">
            <option value="1" selected="selected">1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
          @endif
          @if ($course->creditHour == "2")
           <select name="creditHour" class="form-control">
            <option value="1" >1</option>
            <option value="2" selected="selected">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
          @endif
          @if ($course->creditHour == "3")
           <select name="creditHour" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" selected="selected" >3</option>
            <option value="4">4</option>
          </select>
          @endif
          @if ($course->creditHour == "4")
           <select name="creditHour" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4" selected="selected">4</option>
          </select>
          @endif
        </div>
        <div class="col-md-12">
          <strong>Year Created:</strong>
          <input type="text" name="yearAdd" class="form-control" value="{{$course->yearAdd}}" pattern="\d*">
        </div>
        <div class="col-md-12">
          <strong>Prog ID:</strong>
          <input type="text" name="progId" class="form-control" value="{{$course->progId}}">
        </div>
       
        <div class="col-md-12">
            <br/>
          <a href="{{route('course.index')}}" class="btn btn-sm btn btn-dark">Back</a>
          <button type="submit" name="submit" class="btn btn-indigo">Submit</button>
        </div>
      </div>
    </form>
     
  </div>
@endsection
<?php
        if (isset($_POST['submit'])) {
          $courseCode = $_POST['courseCode'];
          $courseName = $_POST['courseName'];
          $courseDesc = $_POST['courseDesc'];
          $creditHour = $_POST['creditHour'];
          $yearAdd = $_POST['yearAdd'];
          $progId = $_POST['progId'];
          
          $url = "http://localhost:8000/../resources/views/CourseApi.php?courseCode=".$courseCode."&couseName=".$courseName."&courseDesc=".$courseDesc."&creditHour=".$creditHour."&yearAdd=".$yearAdd."&progId=".progId;

          $client = curl_init($url);
          curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
          $response = curl_exec($client);

          $result = json_decode($response);
          
          $msg = "The url is".url;
          return redirect()->back() ->with('alert', $msg);
        }
        ?>