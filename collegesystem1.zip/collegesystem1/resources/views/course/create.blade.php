@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h3>New Course</h3>
      </div>
    </div>

    @if ($errors->any())
      <div class="alert alert-danger">
        <strong>Whoops! </strong> there where some problems with your input.<br>
        <ul>
          @foreach ($errors as $error)
            <li>{{$error}}</li>
          @endforeach
        </ul>
      </div>
    @endif

    <form action="{{route('course.store')}}" method="post">
      @csrf
      <div class="row">
        <div class="col-md-12">
          <strong>Course Code:</strong>
          <input type="text" name="courseCode" class="form-control" placeholder="Course Code" pattern="(?=.*\d)(?=.*[A-Z]).{8}">
        </div>
          <div class="col-md-12">
          <strong>Course Name:</strong>
          <input type="text" name="courseName" class="form-control" placeholder="Course Name">
        </div>
          <div class="col-md-12">
          <strong>Course Description:</strong>
          <input type="text" name="courseDesc" class="form-control" placeholder="Course Description">
        </div>
          <div class="col-md-12">
          <strong>Credit Hour:</strong>
<!--          <input type="text" name="durationOfYear" class="form-control" placeholder="Duration Of Year">-->
           
           <select name="creditHour" class="form-control">
            <option value="1" >1</option>
            <option value="2">2</option>
            <option value="3" >3</option>
            <option value="4">4</option>
          </select>
        
        </div>
          <div class="col-md-12">
          <strong>Year Created:</strong>
          <input type="text" name="yearAdd" class="form-control" placeholder="Year Created" pattern="\d*">
         </div>
          <div class="col-md-12">
          <strong>Programme Name:</strong>
          <select name="progId" class="form-control">
              @foreach ($progs as $prog)
              <option value="{{$prog->id}}" >{{$prog->progCode}}</option>
            @endforeach
              
          </select>
          
          </div>
        
        <div class="col-md-12">
            <br/>
          <a href="{{route('course.index')}}" class="btn btn-sm btn btn-dark">Back</a>
          <button type="submit" class="btn btn-indigo">Submit</button>
        </div>
      </div>
    </form>
    <p>&nbsp;</p>
      <h3>
        <?php
        if (isset($_POST['submit'])) {
          $courseCode = $_POST['courseCode'];
          $courseName = $_POST['courseName'];
          $courseDesc = $_POST['courseDesc'];
          $creditHour = $_POST['creditHour'];
          $yearAdd = $_POST['yearAdd'];
          $progId = $_POST['progId'];
          
          $url = "http://localhost:8000/../resources/views/CourseApi.php?courseCode=" . $courseCode."&couseName=".$courseName."&courseDesc=".$courseDesc."&creditHour=".$creditHour."&yearAdd=".$yearAdd."&progId=".progId;

          $client = curl_init($url);
          curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
          $response = curl_exec($client);

          $result = json_decode($response);
          
          $msg = "The url is".url;
          return redirect()->back() ->with('alert', $msg);
        }
        ?>
          
      </h3>
  </div>
<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
@endsection