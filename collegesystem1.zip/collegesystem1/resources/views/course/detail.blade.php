@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3>Detail Course</h3>
        <hr>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="form-group">
          <strong>Course Code : </strong> {{$course->courseCode}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Course Name : </strong> {{$course->courseName}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Course Description : </strong> {{$course->courseDesc}}
        </div>
      </div>
         <div class="col-md-12">
        <div class="form-group">
          <strong>Credit Hour: </strong> {{$course->creditHour}}
        </div>
      </div>
        <div class="col-md-12">
        <div class="form-group">
          <strong>Year Created: </strong> {{$course->yearAdd}}
        </div>
      </div>
      <div class="col-md-12">
        <div class="form-group">
          <strong>Programme Name: </strong> 
          @foreach ($progs as $prog)
            @if ($course->progId == $prog->id)
            {{$prog->progCode}}
            @endif
          @endforeach
          
        </div>
      </div>
      <div class="col-md-12">
        <a href="{{route('course.index')}}" class="btn btn-sm btn btn-dark">Back</a>
      </div>
    </div>
  </div>
@endsection